# validator.py
import logging
import os
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count, length, countDistinct, expr

def run_validation(current_path, previous_path, country):
    spark = SparkSession.builder.appName("DataValidation").getOrCreate()
    df_current = spark.read.option("header", True).csv(current_path)
    df_previous = spark.read.option("header", True).csv(previous_path)

    os.makedirs("logs", exist_ok=True)
    log_file = f"logs/validation_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    logging.basicConfig(filename=log_file, level=logging.INFO, filemode='w')

    def log(msg): logging.info(msg)

    log("🔍 Row Count Validation")
    row_diff = abs(df_current.count() - df_previous.count()) / df_previous.count()
    if row_diff > 0.02:
        log(f"❌ Row count differs by more than 2%: {row_diff:.2%}")

    log("\n🔍 Store ID Checks")
    df_current.select("store_id").where(col("store_id").isNull()).show()
    null_ids = df_current.filter(col("store_id").isNull()).count()
    if null_ids > 0:
        log(f"❌ {null_ids} rows with null Store ID")

    current_ids = df_current.select("store_id").distinct()
    previous_ids = df_previous.select("store_id").distinct()
    missing_ids = previous_ids.subtract(current_ids).count()
    if missing_ids > 0:
        log(f"❌ {missing_ids} store_ids from previous missing in current")

    log("\n🔍 Duplicate Store ID and Geo")
    duplicates = df_current.groupBy("store_id", "lat", "lon").count().filter("count > 1").count()
    if duplicates > 0:
        log(f"❌ {duplicates} duplicate (store_id, lat, lon) combinations")

    log("\n🔍 Mapping Consistency Checks")
    keys = [("store_id", "store_name"), ("store_id", "store_address"), ("store_id", "city"), ("store_id", "state")]
    for k1, k2 in keys:
        mapping = df_current.groupBy(k1).agg(countDistinct(k2).alias("unique_vals")).filter("unique_vals > 1").count()
        if mapping > 0:
            log(f"❌ Inconsistent mapping: {k1} → {k2} has {mapping} inconsistencies")

    geo_keys = [("store_id", "lat"), ("store_id", "lon")]
    for k1, k2 in geo_keys:
        mapping = df_current.groupBy(k1).agg(countDistinct(k2).alias("unique_vals")).filter("unique_vals > 1").count()
        if mapping > 0:
            log(f"❌ Inconsistent mapping: {k1} → {k2} has {mapping} inconsistencies")

    log("\n🔍 Zip Code Format")
    import re
    zip_col = "zip"
    zip_format = {
        "USA": r"^\d{5}(-\d{4})?$",
        "India": r"^\d{6}$",
        "Germany": r"^\d{5}$",
        "UK": r"^[A-Z]{1,2}\d[A-Z\d]? ?\d[A-Z]{2}$"
    }.get(country, r".*")

    invalid_zip = df_current.filter(~col(zip_col).rlike(zip_format)).count()
    if invalid_zip > 0:
        log(f"❌ {invalid_zip} invalid zip codes for {country}")

    log("\n🔍 Geo Bounds")
    bounds = {
        "USA": (24.5, 49.5, -125, -66),
        "India": (6, 37, 68, 97),
        "Germany": (47, 55, 5, 15),
        "UK": (49, 60, -9, 2)
    }.get(country, (None, None, None, None))
    if bounds != (None, None, None, None):
        lat_invalid = df_current.filter((col("lat") < bounds[0]) | (col("lat") > bounds[1])).count()
        lon_invalid = df_current.filter((col("lon") < bounds[2]) | (col("lon") > bounds[3])).count()
        if lat_invalid > 0 or lon_invalid > 0:
            log(f"❌ {lat_invalid} invalid latitudes or {lon_invalid} invalid longitudes")

    log("\n🔍 Price Format")
    price_col = "price"
    outliers = df_current.withColumn("p", col(price_col).cast("float")).select("p").summary("min", "max").collect()
    if outliers:
        log(f"ℹ️ Price Summary: min={outliers[0]['p']}, max={outliers[1]['p']}")

    log("\n🔍 Currency Symbol")
    currency = {
        "USA": "$",
        "India": "₹",
        "Germany": "€",
        "UK": "£"
    }.get(country, "")
    if currency:
        symbol_missing = df_current.filter(~col(price_col).contains(currency)).count()
        if symbol_missing > 0:
            log(f"❌ {symbol_missing} rows missing currency symbol '{currency}' in price")

    log_file_path = os.path.abspath(log_file)
    return log_file_path
