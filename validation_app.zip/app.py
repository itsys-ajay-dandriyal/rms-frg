# app.py
import streamlit as st
from validator import run_validation

st.set_page_config(page_title="Data Validator", layout="centered")
st.title("📊 Dataset Comparison Validator")

# File upload
uploaded_file1 = st.file_uploader("Upload Current Dataset (CSV)", type=["csv"], key="file1")
uploaded_file2 = st.file_uploader("Upload Previous Dataset (CSV)", type=["csv"], key="file2")

# Country selection
country = st.selectbox("Select Country", ["USA", "India", "Germany", "UK"])

# Trigger validation
if uploaded_file1 and uploaded_file2 and st.button("Run Validation"):
    with open("temp_current.csv", "wb") as f1:
        f1.write(uploaded_file1.read())
    with open("temp_previous.csv", "wb") as f2:
        f2.write(uploaded_file2.read())

    st.info("Running validation... Please wait.")
    log_file = run_validation("temp_current.csv", "temp_previous.csv", country)

    st.success("Validation completed. Showing log below:")
    with open(log_file, "r") as lf:
        log_content = lf.read()
        st.text_area("Validation Log", log_content, height=400)

    st.download_button(
        label="📥 Download Log File",
        data=log_content,
        file_name=log_file.split("/")[-1],
        mime="text/plain"
    )
